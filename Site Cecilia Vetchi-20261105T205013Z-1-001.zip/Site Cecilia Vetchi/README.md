# Cecilia Vetchi — proposta de layout

Protótipo responsivo em React, Vite e TypeScript. O escopo desta entrega é o design navegável. Não há backend, coleta de e-mails, publicação em produção ou sincronização automática com redes sociais.

## Executar

Com Node.js 22.12+ ou 24+ e npm:

```powershell
npm install
npm run dev
```

Para conferir tipos e gerar a versão estática:

```powershell
npm run build
npm run preview
```

O Google Drive virtual pode impedir a extração de dependências do npm no Windows. Se ocorrer `TAR_ENTRY_ERROR`, copie o projeto para um diretório local fora do Drive antes de instalar. A prévia desta entrega usa uma cópia em `C:\Users\Julia\.codex\work\cecilia-vetchi-layout`.

## Direção visual

- Referência fornecida: fundo creme, tinta quase preta, verde ácido e escrita manual expressiva.
- Cores aproximadas da imagem: creme `#F7F6EA`, preto `#191919`, verde `#D6FF00`. Não são amostras oficiais de marca.
- `Caveat Brush` aproxima o gesto da referência. A fonte exata não pode ser determinada pela imagem e deverá ser fornecida para correspondência fiel. `DM Sans` é a fonte de navegação e leitura.
- Material Design 3 como base de papéis semânticos, foco, estados, áreas de toque e componentes; expressão editorial personalizada, com superfícies planas e poucos arredondamentos.
- Tokens de cores, tipos, espaços, movimento, formas e elevação em `src/tokens.css`. Breakpoints de composição documentados no mesmo arquivo e implementados em `src/styles.css`.

Referências consultadas em 18/10/2026:

1. [The Gentlewoman](https://thegentlewoman.co.uk/): convivência entre conteúdo editorial, perfis de mulheres e colaborações. Inspirou a divisão das áreas e a hierarquia de leitura.
2. [TORTUS](https://tortus.dk/): apresentação de cerâmicas, ateliê e processo. Inspirou a galeria e o destaque para o fazer manual.

## Conteúdo e interações

- Abertura, artigos com filtros, projeto com Shell Nascimento, galeria, biografia, redes sociais e colaborações.
- Menu responsivo, links de seção e modais acessíveis com fechamento por Escape, clique externo e botão; foco restaurado ao acionador.
- Artigos e imagens são demonstrativos, explicitamente sinalizados. Não foram atribuídos prêmios, formação, currículo ou textos reais a Cecilia.
- “Clube Insano” é uma aplicação sugerida do lettering do anexo; ainda não foi confirmado como nome do projeto com Shell.
- Sem retrato fictício apresentado como Cecilia. A biografia usa uma composição tipográfica.

## Conectar conteúdo real

1. Os links oficiais fornecidos de Substack, Instagram, TikTok e YouTube já estão em `channels`, em `src/content.ts`. O Spotify abre informações sobre o espaço reservado até seu endereço ser confirmado.
2. Substituir as propostas de artigos e as fotos pelas publicações e peças aprovadas.
3. Confirmar biografia, nome do projeto com Shell, fonte original e contato profissional.

Uma implementação posterior poderá usar o feed RSS autorizado do Substack e incorporar publicações ou episódios oficiais das outras plataformas. Essa integração dependerá dos endereços e dos formatos disponíveis; não está implementada nesta proposta. Não há raspagem nem autenticação em redes sociais.

## Fotografias ilustrativas

Fotografias do Unsplash, usadas como referências visuais, não como obras ou retratos de Cecilia:

- [Jonathan Cosens Photography — mãos no torno](https://unsplash.com/photos/a-person-is-making-clay-on-a-wheel-ObocATAlfE8)
- [Quino Al — processo em preto e branco](https://unsplash.com/photos/person-doing-pot-j-vgwo8di98)
- [Chloe Bolton — vasos em tons naturais](https://unsplash.com/photos/ceramic-vases-on-wooden-surface-R0qthXq3jec)

As fontes são carregadas pelo Google Fonts; as fotografias ficam no próprio projeto. Nenhum recurso de nuvem foi provisionado.

## Validação da entrega

- Verificação estrita de tipos e build Vite concluídos na cópia local.
- Navegador Chrome: filtros, modais, Escape, restauração de foco, galeria, projeto, menu móvel, navegação e carregamento de imagens verificados.
- Sem erros JavaScript e sem rolagem horizontal nas larguras 320, 375, 390, 760, 768, 1024 e 1440 pixels.
- Capturas de desktop e celular, e registro das verificações, em `design/`.
- Versão estática gerada em `dist/`. Não houve deploy no Amplify; esta entrega é uma proposta de layout para revisão.
